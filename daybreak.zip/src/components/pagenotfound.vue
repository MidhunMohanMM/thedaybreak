<template>
    <h1 class= "uk-text-muted padding uk-text-center">Oh no! The content you are looking isn't here, try checking the URL ☹</h1>
</template>
<script>
export default {
    
}
</script>
<style scoped>
.padding{
    padding-top:150px;
    padding-bottom:150px;
    margin-left:200px;
    margin-right:150px;
}
</style>
