<template>
    <div style="min-height: 100vh;">
        <h1 class= "uk-text-muted padding uk-text-center">The content you are looking was supposed to be here , maybe we missed them, check after some time ☹</h1>
    </div>
</template>
<script>
export default {
    
}
</script>
<style scoped>
.padding{
    padding-top:150px;
    padding-bottom:250px;
    margin-left:200px;
    margin-right:150px;
}
</style>
