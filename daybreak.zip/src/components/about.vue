<template>
    <main style="min-height:2000px;">
        <div class="section uk-padding-small" id="desktop">
            <div class="uk-container articlebg uk-padding-small">
                <div uk-grid>
                    <div class="uk-width-1-1">
                        <article class="abtart uk-article">
                            <div class="uk-child-width-1-1@m uk-text-center uk-margin-large uk-margin-remove-bottom">
                                <h1 class='uk-heading-line uk-text-center uk-padding-top'>
                                    <span class='pageheadd'>About Us 💡</span>
                                </h1>
                            </div>
                            <div class="uk-child-width-expand@s uk-text-center " uk-grid>
                                <div>
                                    <br>
                                    <div class="uk-card uk-card-default uk-card-body">
                                        <img width="430px" class="uk-margin-remove-bottom uk-align-center" src="/src/assets/logo.png" alt="Daybreak">
                                        <hr class="uk-divider-icon uk-margin-small">
                                        <p class="uk-margin-remove-top uk-text-justify" style="font-size:inherit;">The Day Break is a newspaper devoted to delivering 
                                        news and features to help students pursue their academic ambitions while assisting parents and 
                                        teachers to be well informed about educational issues happening around. The fortnightly publication 
                                        has sections like schooling, well-being, lifestyle, recreations, and perspectives, with the intent to 
                                        connect school syllabus with the daily life of a student.</p>
                                    </div>
                                </div>
                                <div>
                                    <div class="uk-card uk-card-default uk-card-body logo">
                                        <img width="200px" class="uk-margin-remove-bottom uk-align-center" src="/src/assets/poshpublogo.png" alt="Posh Advertising Logo">
                                        <hr class="uk-divider-icon uk-margin-small">
                                         <p class="uk-margin-remove-top uk-text-justify" style="font-size:inherit;">Posh Advertising has been successfully running for the past 30 years in the Advertising Sector. Posh Publications
                                        is their new vertical and initiative in the readable media sector. The DayBreak Newspaper is their first
                                        venture exclusively for the students and their parents who are on the lookout for suitable career guidance to establish a fruitful future.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="uk-card uk-card-default uk-card-body cardstyle">
                                <h3 class="uk-heading-line uk-text-center uk-margin-remove-bottom">
                                    <span style="font-size: 2.5rem;">Vision</span>
                                </h3>
                                <p class="uk-margin-remove-top uk-text-center" style="font-size:inherit;">We look forward to a world with enlightened minds that are wise in dealing with the challenges
                                    of the society and compassionate towards everything around. For that, we believe in a media, readable
                                    for young buds that will deliver a culture of professionalism, reinforces them to become global citizens
                                    and inspires them to be the leaders of tomorrow.</p>
                            </div>
                            <div class="uk-card uk-card-default uk-card-body cardstyle">
                                <h3 class="uk-heading-line uk-text-center uk-margin-remove-bottom"><span style="font-size: 2.5rem;">Mission</span></h3>
                                <p class="uk-margin-remove-top uk-text-center" style="font-size:inherit;">The Day Break is a dedicated news organisation for students, committed in providing news in a format
                                    accessible to the young minds and to transcend the possibilities of education and news media. It
                                    offers a unique blend of news, culture, education, health, sports, travel and editorials. Every student
                                    deserves a better reading experience to know the developments around. We are nurturing a culture
                                    where news will be centred on vital challenges for large-scale improvements with real stories designed
                                    to make students reflect aptitude and imagination.</p>
                            </div>
                        </article>
                    </div>
                </div>
            </div>
        </div>


    </main>
</template>
<script>
export default {
}
</script>
<style scoped>
.logo{
    margin-top: 26px;
    margin-bottom: 51px;
    height: 449px;
}
.cardstyle{
    margin-bottom: 51px;
}



</style>
