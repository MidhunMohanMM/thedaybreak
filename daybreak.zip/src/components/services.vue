<template>
    <main>
    <div class="section uk-padding-small">
        <div class="uk-container articlebg uk-padding-small">
            <div uk-grid>
                <div class="uk-width-1-1">
                    <article class="abtart uk-article">
                        <div class="uk-child-width-1-1@m uk-text-center uk-margin-large uk-margin-remove-bottom">
                            <h1 class='uk-heading-line uk-text-center uk-padding-top'>
                                    <span class='pageheadd'>Services We Provide 💝</span>
                            </h1>
                        </div>
                        <br>
                        <p class="uk-margin-remove-top uk-text-center" style="font-size:inherit;">
                            The Team at DayBreak offers a wide variety of services for students and their parents to improve the quality of education
                            and to experience life to the fullest. This range from training to entertainment, counselling to events and also competition
                            to exhibitions.
                        </p>
                        <div class="uk-grid-small uk-grid-match uk-height-match" uk-grid>
                            <div class="uk-width-1-4@m">
                                <div class="uk-card  uk-card-default uk-card-hover uk-border-rounded uk-box-shadow-hover-medium uk-card-body uk-card-small">
                                    <img class="uk-align-center" style="margin-bottom:2px;" src="/src/assets/services/news.svg" width="55" height="55" uk-svg>
                                    <dl class="uk-margin-remove-top">
                                        <dt class="uk-text-center">Newspaper/Magazines</dt>
                                        <dd class="uk-text-center">The DayBreak delivers quality news which will provide the students with insights on all latest aspects. It will
                                        be a guide for moulding their future.</dd>
                                    </dl>
                                </div>
                            </div>
                            <div class="uk-width-1-4@m">
                                <div class="uk-card uk-border-rounded uk-card-hover uk-card-default uk-box-shadow-hover-medium uk-card-body uk-card-small">
                                    <img class="uk-align-center" style="margin-bottom:2px;" src="/src/assets/services/Health.svg" width="55" height="55" uk-svg>
                                    <dl class="uk-margin-remove-top">
                                        <dt class="uk-text-center">Health Campaigns and Activities</dt>
                                        <dd class="uk-text-center">The main aim of conducting health campaigns is to encourage students so that they adopt a healthy lifestyle for
                                        their well being.</dd>
                                    </dl>
                                </div>
                            </div>
                            <div class="uk-width-1-4@m">
                                <div class="uk-card uk-border-rounded uk-card-hover uk-card-default uk-box-shadow-hover-medium uk-card-body uk-card-small">
                                    <img class="uk-align-center" style="margin-bottom:2px;" src="/src/assets/services/tour.svg" width="55" height="55" uk-svg>
                                    <dl class="uk-margin-remove-top">
                                        <dt class="uk-text-center">Educational & Industrial Tours</dt>
                                        <dd class="uk-text-center">Interactive educational tours will be conducted for students to give them the practical knowledge related to
                                        their studies.</dd>
                                    </dl>
                                </div>
                            </div>
                            <div class="uk-width-1-4@m">
                                <div class="uk-card  uk-border-rounded uk-card-hover uk-card-default uk-box-shadow-hover-medium uk-card-body uk-card-small">
                                    <img class="uk-align-center" style="margin-bottom:2px;" src="/src/assets/services/entertainment.svg" width="55" height="55" uk-svg>
                                    <dl class="uk-margin-remove-top">
                                        <dt class="uk-text-center">Entertainment, Events & Summer classes</dt>
                                        <dd class="uk-text-center">It will not be all work and no play at the Day Break. Special entertainment events will be conducted regularly
                                        which also includes summer classes for students during holidays.</dd>
                                    </dl>
                                </div>
                            </div>
                        </div>
                        <div class="uk-grid-small uk-grid-match uk-height-match" uk-grid>
                            <div class="uk-width-1-3@m">
                                <div class="uk-card uk-border-rounded uk-card-hover uk-card-default uk-box-shadow-hover-medium uk-card-body uk-card-small">
                                    <img class="uk-align-center" style="margin-bottom:2px;" src="/src/assets/services/counselling.svg" width="55" height="55" uk-svg>
                                    <dl class="uk-margin-remove-top">
                                        <dt class="uk-text-center">Counselling</dt>
                                        <dd class="uk-text-center">If any student requires personal attention with respect to counselling, trained counsellors are available to
                                        help in the best way possible. Various counselling available are Health, Safety & Well-being and Environmental.
                                            <div class="uk-text-small"></div>
                                        </dd>
                                    </dl>
                                </div>
                            </div>
                            <div class="uk-width-1-3@m">
                                <div class="uk-card uk-border-rounded uk-card-hover uk-card-default uk-box-shadow-hover-medium uk-card-body uk-card-small">
                                    <img class="uk-align-center" style="margin-bottom:2px;" src="/src/assets/services/training.svg" width="55" height="55" uk-svg>
                                    <dl class="uk-margin-remove-top">
                                        <dt class="uk-text-center">Training</dt>
                                        <dd class="uk-text-center">Training for students in various fields is essential for the proper development of their skills and behaviour
                                        management. At the Day Break, students can enroll for the training such as,
                                        Personality Development, Skill Development, Career Development, Academic, Science & Technology, Safety Training
                                            <div class="uk-text-small"></div>
                                        </dd>
                                    </dl>
                                </div>
                            </div>
                            <div class="uk-width-1-3@m">
                                <div class="uk-card uk-border-rounded uk-card-hover uk-card-default uk-box-shadow-hover-medium uk-card-body uk-card-small">
                                    <img class="uk-align-center" style="margin-bottom:2px;" src="/src/assets/services/OtherAct.svg" width="55" height="55" uk-svg>
                                    <dl class="uk-margin-remove-top">
                                        <dt class="uk-text-center">Other Activities
                                        <br>(for Students, Teachers and Parents)</dt>
                                        <dd class="uk-text-center">Various other activities which are vital for the development of students, that also play a part in parents’ and
                                        teachers’ lives will be conducted.</dd>
                                    </dl>
                                </div>
                            </div>
                        </div>
                    </article>
                </div>
            </div>
        </div>
    </div>
</main>
</template>
<script>
export default {
    
}
</script>
<style scoped>

</style>
